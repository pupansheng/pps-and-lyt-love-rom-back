<template>
	<view class="content">
		<u-notice-bar style="width:100%;" mode="horizontal" :list="list"></u-notice-bar>
		<view style="width:100%;">


			<u-subsection :list="typeList" :current="curNow" @change="sectionChange"></u-subsection>

			<view v-if="curNow==0">
				<u-cell-group>
					<u-cell-item icon="star-fill" :title="v.fileName" :key="v.id" @click="slelectPerson(v)" v-for="v in videoList"></u-cell-item>
				</u-cell-group>
			</view>

			<view v-if="curNow==1">

				<u-search placeholder="输入电影名开始爬取资源" :show-action="false" @search="searchVideo" v-model="keyword"></u-search>
				<u-tabs :list="resourceList" :is-scroll="true" :current="currentTab" @change="changeTab"></u-tabs>
				<view v-if="showList">

					<view style="margin-top: 300rpx;" v-if="searchVideoList.length<=0">

						<u-empty text="没有爬取到内容" mode="list"></u-empty>

					</view>
					<view v-else>


						<u-card :key="k" v-for="(v,k) in searchVideoList" :title="v.name" :thumb="v.image" @click="searchPlayLink(v)">
							<view class="" slot="body">
								<view>
									<image :src="v.image" mode="aspectFill"></image>
								</view>
								<view>
									{{v.detail}}
								</view>

							</view>
						</u-card>


					</view>



				</view>

				<view v-else>

					<u-cell-group>
						<u-cell-item icon="star-fill" :title="v.name" :key="k" @click="getHttpLink(v)" v-for="(v,k) in playList"></u-cell-item>
					</u-cell-group>

				</view>

			</view>








		</view>
		<view>
			<u-popup v-model="show">

				<view style="width: 400rpx;">
					<u-icon name="man-add-fill"></u-icon>添加观看人员
				</view>
				<u-divider color="#fa3534" half-width="200" border-color="#6d6d6d">------------</u-divider>
				<view>

					<u-cell-group>
						<u-cell-item :key="k" v-for="(v,k) in userList" :title="v.name" @click="gotoMovie(v)">
							<view slot="icon">
								<u-avatar :src="v.userInfoPo==null?'':v.userInfoPo.headImage" size="mini"></u-avatar>
							</view>
						</u-cell-item>
					</u-cell-group>


				</view>


			</u-popup>
		</view>
	</view>
</template>

<script>
	import API from "../../common/resource.js"
	export default {
		data() {
			return {
				list: [
					'蒲蒲',
					'深爱',
					'猪猪'

				],
				videoList: [],
				resourceList: [],
				currentTab: 0,
				userList: [],
				show: false,
				video: {},
				keyword: '',
				curNow: 1,
				showList: true,
				searchVideoList: [],
				playList: [],
				typeList: [{
						name: '本地视频资源'
					},
					{
						name: '爬虫爬取资源'
					},
				]

			}
		},
		onLoad() {

			if (!this.isLogin) {

				if (this.vuex_token) {
					this.$u.post(API.getLoginInfo).then(res => {
						this.$u.vuex('vuex_user', res.data);
						this.$u.vuex('isLogin', true);
						uni.$emit('loginSuccess', {
							msg: '登陆成功'
						})
						this.getList();
						this.getResource()
					}, err => {
						this.$ppsUtil.log("请求个人页面出现错误  进入登陆页面")
						this.$ppsUtil.goLoginPage();
					});
				} else {
					this.$ppsUtil.log("未登录 进入登陆页面")
					this.$ppsUtil.goLoginPage();
				}
			}


		},
		methods: {
			changeTab(v) {
				this.currentTab = v;
				if (this.keyword) {
					this.searchVideo(this.keyword)
				}
			},
			getHttpLink(v) {

				this.$u.post(API.getVideoLink, {
					resourceId: v.url,
					source: this.resourceList[this.currentTab].name
				}).then(res => {

					let link = res.data;
					let p = {
						url: link,
						fileName: v.name
					};
					this.slelectPerson(p)
				})

			},
			searchPlayLink(v) {

				this.$u.post(API.clickVideo, {
					link: v.link,
					source: this.resourceList[this.currentTab].name
				}).then(res => {
					this.showList = false;
					let playList = res.data;
					this.playList = playList;

				})



			},
			searchVideo(v) {
				this.searchVideoList = [];
				this.showList = true;
				this.$u.post(API.searchVideo, {
					keyword: v,
					source: this.resourceList[this.currentTab].name
				}).then(res => {
					this.searchVideoList = res.data;
				})

			},
			sectionChange(index) {
				this.curNow = index;
			},
			getList() {
				this.$ppsUtil.log("获取影片")
				this.$u.post(API.getVideoList).then(res => {
					this.videoList = res.data;
				})

			},
			slelectPerson(v) {
				this.video = v;
				this.show = true;
				this.$u.post(API.getOnile).then(res => {
					this.userList = res.data;
					if (this.userList.length == 0) {
						this.userList.push({
							name: "代码蒲蒲(系统)单人观看使用"
						})
					}
				})


			},
			getResource() {

				this.$u.post(API.getResource).then(res => {
					this.resourceList = [];
					res.data.forEach(p => {
						this.resourceList.push({
							name: p
						})
					})
					this.$ppsUtil.log(this.resourceList)

				})

			},
			gotoMovie(u) {
				let s = "item=" + JSON.stringify(u) + "&video=" + encodeURIComponent(JSON.stringify(this.video));
				let send = {
					video: this.video,
					inviter: {
						id: this.vuex_user.userInfo.id,
						name: this.vuex_user.userInfo.name
					}
				}
				this.$im.sendMsgForText(JSON.stringify(send), u.name, 9, 1);
				uni.navigateTo({
					url: '/pages/video/index?' + s + "&master=true"
				});

			}

		},
		onReady() {
			if (this.isLogin) {
				this.getList();
				this.getResource();
			}

		},
		onPullDownRefresh() {

			this.getList();
			setTimeout(function() {
				uni.stopPullDownRefresh();
			}, 1000);
		}
	}
</script>

<style lang="scss" scoped>
	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		padding: 40rpx;
	}

	.wrap {
		padding: 40rpx;
	}
</style>

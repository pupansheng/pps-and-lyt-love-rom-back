<template>
	<view>
		
		<u-navbar :is-back="false" title="　" :border-bottom="false">
			<view class="u-flex u-row-right" style="width: 100%;">
				<view class="camera u-flex u-row-center">
					<u-icon name="camera-fill" color="#000000" size="48"></u-icon>
				</view>
			</view>
		</u-navbar>
		<view class="u-flex user-box u-p-l-30 u-p-r-20 u-p-b-30">
			<view class="u-m-r-10" >
				<u-avatar @click="chooseAvatar()" :src="vuex_user!=null?vuex_user.userInfoExt.headImage:''" size="140"></u-avatar>
			</view>
			<view class="u-flex-1">
				<view class="u-font-18 u-p-b-20"></view>
				<view class="u-font-14 u-tips-color">用户名:{{vuex_user!=null?vuex_user.userInfo.name:'未登录'}}</view>
			</view>
			<view class="u-m-l-10 u-p-10">
				<u-icon name="scan" color="#969799" size="28"></u-icon>
			</view>
			<view class="u-m-l-10 u-p-10">
				<u-icon name="arrow-right" color="#969799" size="28"></u-icon>
			</view>
		</view>
		
		<view class="u-m-t-20">
			<u-cell-group>
				<u-cell-item icon="rmb-circle" title="支付"></u-cell-item>
			</u-cell-group>
		</view>
		
		<view class="u-m-t-20">
			<u-cell-group>
				<u-cell-item icon="star" title="收藏"></u-cell-item>
				<u-cell-item icon="photo" title="相册"></u-cell-item>
				<u-cell-item icon="coupon" title="卡券"></u-cell-item>
				<u-cell-item icon="heart" title="关注"></u-cell-item>
			</u-cell-group>
		</view>
		
		<view class="u-m-t-20">
			<u-cell-group>
				<u-cell-item icon="setting" title="刷新个人信息" @click="freshInfo"></u-cell-item>
				<u-cell-item icon="setting" title="退出登录" @click="logout"></u-cell-item>
			</u-cell-group>
		</view>
	</view>
</template>

<script>
	import API from "../../common/resource.js"
	export default {
		data() {
			return {
				pic:'https://uviewui.com/common/logo.png',
				show:true
			}
		},
		onLoad() {
			
		},
		created() {
					// 监听从裁剪页发布的事件，获得裁剪结果
					uni.$on('uAvatarCropper', path => {
						// 可以在此上传到服务端
						uni.uploadFile({
						           url: this.$u.http.config.baseUrl+"/"+API.uploadSimple, //仅为示例，非真实的接口地址
								   filePath:path,
						           name: 'file',
								   timeout:600000,
									header:{
										'authorization':this.vuex_token
									 },
						           success: (res) => {
								    let t=	res.data;
									let url=(JSON.parse(t)).data
									console.log(res)
									let user={
										userId:this.vuex_user.userInfo.id,
										headImage:url
									}
								
									this.showList=true;
									this.$u.post(API.updateExtInfo,user).then(res=>{
										let t=res.data;
										this.vuex_user.userInfoExt=t; 
										this.$ppsUtil.successToast()("更新头像成功")
									})
									
																				   
						           },
									complete:(e)=>{
										
									}
						      });
						
					})
		},
		methods: {
			
			chooseAvatar() {
							// 此为uView的跳转方法，详见"文档-JS"部分，也可以用uni的uni.navigateTo
							this.$u.route({
								// 关于此路径，请见下方"注意事项"
								url: '/uview-ui/components/u-avatar-cropper/u-avatar-cropper',
								// 内部已设置以下默认参数值，可不传这些参数
								params: {
									// 输出图片宽度，高等于宽，单位px
									destWidth: 300,
									// 裁剪框宽度，高等于宽，单位px
									rectWidth: 200,
									// 输出的图片类型，如果'png'类型发现裁剪的图片太大，改成"jpg"即可
									fileType: 'jpg',
								}
							})
			},
			logout(){
				
				 this.$ppsUtil.clearData();
				 this.$ppsUtil.successToast("退出成功")
				 this.$ppsUtil.delayMethodExecute(()=>{
					  this.$ppsUtil.goLoginPage();
				 })
				
				 
			},
			freshInfo(){
				this.$u.post(API.getLoginInfo).then(res => {
					this.$ppsUtil.successToast("刷新成功")
				    this.$u.vuex('vuex_user',res.data);
				});
				
			}
		}
	}
</script>

<style lang="scss">
page{
	background-color: #ededed;
}

.camera{
	width: 54px;
	height: 44px;
	
	&:active{
		background-color: #ededed;
	}
}
.user-box{
	background-color: #fff;
}
</style>

<template>
	<view class="wrap">
            <u-toast ref="uToast" />
		
		<u-tabs :list="typeList" :is-scroll="true" :current="currentTab" @change="changeTab"></u-tabs>	
		<view v-if="currentTab==0">
		<view style="display: flex;flex-direction: row;justify-content: center;margin-top: 250rpx;">
			<u-button @click="openFile" type="primary">选择影片</u-button>
		</view>
		<view>
			<u-line-progress v-show="showPro" :percent="prercent" :round="false" active-color="green"></u-line-progress>
		</view>
        </view>
        <view v-if="currentTab==1" style="margin-top: 20rpx;">
		
		       <u-field
		  			v-model="name"
		  			label="影片名称"
		  			placeholder="请填写影片名称"
		  		>
		  		</u-field>
		  		<u-field
		  			v-model="link"
		  			label="链接"
		  			placeholder="可以直接播放的链接"
		  		>
		  		</u-field>
		
		      <u-button @click="uploadMovie" type="primary" style="margin-top: 30rpx;">上传</u-button>
		
		
        </view>
		<view v-if="currentTab==2" style="margin-top: 20rpx;">
		
		  		
		  		<u-field
		  			v-model="htmlE.url"
		  			label="链接"
		  			placeholder="网页链接"
		  		>
		  		</u-field>
		        <u-field
			      v-model="hk"
			       label="请求头key"
		          >
				  </u-field>
				  <u-field
				    v-model="hv"
				     label="请求头value"
				    >
					</u-field>
				<u-divider>----自定义头信息----：</u-divider>	
		         <u-read-more>
		     		<rich-text :nodes="JSON.stringify(htmlE.header)"></rich-text>
		     	</u-read-more>
			   <u-button @click="addH" type="primary" style="margin-top: 30rpx;">添加自定义头</u-button>
			  
		           <u-button @click="searchH" type="primary" style="margin-top: 30rpx;">分析页面</u-button>
			    
			  	 <u-divider >----响应信息html({{responseH.statusCode}})----：</u-divider>
				
				<u-divider>头信息：</u-divider>
				<text>{{responseH.responseHeader}}</text>
				<u-divider>html元素：</u-divider>
				<text>{{responseH.html}}</text>
				
			    <u-button @click="openx" type="primary" style="margin-top: 30rpx;">打开渲染页面</u-button>
				
						
			     <view v-if="show">
				<u-divider style="margin-top: 30rpx;">----响应信息渲染----：</u-divider>
				<view style="height: 200rpx;height: 300rpx;">
					<u-parse :html="responseH.html" ></u-parse>
				</view>
		       </view>
		      
		           
		</view>
	</view>

</template>

<script>
	import API from "../../common/resource.js"
	export default {
		data() {
			return {

				showPro: false,
				prercent: 0,
				show:false,
				currentTab:0,
				typeList:[{
					name:"本地上传",
				
				},{
					name:"视频外链上传"
				},{
					name:"分析元素"
				}],
				name:'',
				link:'',
			    hk:'',
				hv:'',
				htmlE:{
					url:'',
				    header:{}
				},
				responseH:{}

			}

		},
		methods: {
			openx(){
				this.show=!this.show;
			},
			searchH(){
				if(!this.htmlE.url){
					this.$ppsUtil.errorToast("未填写完整")
					return;
				}
				this.$u.post(API.anlyHtml, {
					url:this.htmlE.url,
					header:this.htmlE.header
				}).then(res => {
					
					let h= res.data;
					this.responseH=h;
				
				})
				
			},
			addH(){
				if(!this.hk||!this.hv){
					this.$ppsUtil.errorToast("未填写完整")
					return;
				}
				this.htmlE.header[this.hk]=this.hv;
				this.$ppsUtil.successToast("添加成功！")
				this.hk=''
				this.hv=''
			},
			uploadMovie(){
				if(!this.name||!this.link){
					this.$ppsUtil.errorToast("未填写完整")
					return;
				}
				this.$u.post(API.uploadMovie, {
					key: this.name,
					fileName:this.name,
					url:this.link,
					userId:this.vuex_user.userInfo.id
				}).then(res => {
					
					this.$ppsUtil.successToast("上传成功")
					this.link="";
					this.name="";
				
				})
				
				
			},
			changeTab(v) {
				this.currentTab = v;
				if (this.keyword) {
					this.searchVideo(this.keyword)
				}
			},
			openFile() {
				let vm = this;
				uni.chooseVideo({
					count: 1,
					compressed: false,
					sourceType: ['camera', 'album'],
					success: function(res) {
						let file = res.tempFile;
						vm.initChunkUpload(file)
					}
				});
			},
			initChunkUpload(file){
			let bytesPerPiece = 2 * 1024 * 1024;
			//计算文件切片总数
			let filesize = file.size;
			let totalPieces = Math.ceil(filesize / bytesPerPiece);	
			let s=this.vuex_user.userInfo.name+":"+file.name+file.size+file.type+file.lastModified;
			this.$u.post(API.initUpload,{
				sign:s,
				name:file.name,
				user:this.vuex_user.userInfo.name,
				userId:this.vuex_user.userInfo.id,
				pageSize:totalPieces
			}).then(res => {
			  
			  let data=  res.data;
			  this.uploadChunck(data,totalPieces,file,bytesPerPiece)
			  this.queryProcess(data,totalPieces)
			  
			});
				
			},
			queryProcess(data,t){
				
			  let uploadId=data.uploadId;
			  let key=data.key;
				
              let task=setInterval(()=>{
				  
				  this.$u.post(API.searchProcess,data).then(res => {
				    let p=  res.data;
					if(p==t){
						clearInterval(task);
						  this.$u.post(API.completeUpload,{
							  ...data,
							  userId:this.vuex_user.userInfo.id
							  }).then(res2=>{
							this.$refs.uToast.show({
								   title: '上传成功',
								   type: 'success'				
							})
							this.showPro=false;
							this.$ppsUtil.log("合成成功！")
							this.prercent=0;
						  },err=>{
							this.showPro=false;
							this.$ppsUtil.log("合成失败！")
							this.prercent=0;
						  })
					}
				    this.prercent = Math.round(( p/ t) * 100, 2);
				  },err=>{
					  this.$ppsUtil.log("请求进度失败！")
					  clearInterval(task);
					  this.showPro=false;
				  });
				  
			  },3000);
				
		
			},
		   async	uploadChunck(data,totalPieces,file,bytesPerPiece){
				this.prercent=0;
				this.showPro=true;
				let startPage=data.pageNumber;
				let uploadId=data.uploadId;
				let key=data.key;
				let blob = file
				let start = 0+(startPage-1)*bytesPerPiece;
				let end;
				let index = startPage;
				let filesize = file.size;
				while (start < filesize) {
					end = start + bytesPerPiece;
					if (end > filesize) {
						end = filesize;
					}
					var chunk = blob.slice(start, end); //切割文件    
					let param={
						"pageNumber":index,
						"fileName":file.name,
						"uploadId":uploadId,
						"key":key,
						"size":end-start
					}
					
				    await this.httpUpload(param,chunk);
					this.$ppsUtil.log("分块上传：块"+index);
					start = end;
					index++;
				}
			},
		    async httpUpload(form,chunk){
			
			 uni.uploadFile({
			            url: this.$u.http.config.baseUrl+"/"+API.uploadChunck, //仅为示例，非真实的接口地址
						file:chunk,
			            name: 'file',
						timeout:600000,
			            formData:form,
						header:{
							'authorization':this.vuex_token
						},
			            success: (res) => {
														   
			            },
						complete:(e)=>{
							console.log(e)
						}
			       });
			},
		},
		onReady() {





		}
	}
</script>

<style lang="scss">
	.wrap {
		padding: 24rpx;
		justify-content: center;
		flex-direction: column;
		display: flex;
	}

	.slot-btn {
		width: 341rpx;
		height: 140rpx;
		display: flex;
		justify-content: center;
		align-items: center;
		background: rgb(244, 245, 246);
		border-radius: 10rpx;
	}

	.slot-btn__hover {
		background-color: rgb(235, 236, 238);
	}

	.pre-box {
		display: flex;
		align-items: center;
		justify-content: space-between;
		flex-wrap: wrap;
	}

	.pre-item {
		flex: 0 0 48.5%;
		border-radius: 10rpx;
		height: 140rpx;
		overflow: hidden;
		position: relative;
		margin-bottom: 20rpx;
	}

	.pre-item-image {
		width: 100%;
		height: 140rpx;
	}
</style>

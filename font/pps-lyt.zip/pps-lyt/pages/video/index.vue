<template>
	<view class="content">


		<view>
			<view class="uni-padding-wrap uni-common-mt">
				<view>
					<video id="myVideo" :title="video.fileName" :src="video.url" :controls="true" :show-center-play-btn="master"
					 @error="videoErrorCallback" :danmu-list="danmuList" @play="videoEvent('play',$event)" @ended="videoEvent('ended',$event)"
					 @timeupdate="videoEvent('timeUpdate',$event)" @fullscreenchange="videoEvent('full',$event)" @waiting="videoEvent('waiting',$event)"
					 @progress="videoEvent('progress',$event)" @ontimeupdate="videoEvent('h5timeUpdate',$event)" @pause="videoEvent('pause',$event)"
					 enable-danmu danmu-btn controls></video>

				</view>
				<!-- 	@timeupdate="videoEvent('timeUpdate',$event)" -->
				<!-- #ifndef MP-ALIPAY -->
				<view class="uni-list uni-common-mt">
					<view class="uni-list-cell">
						<view>
							<view class="uni-label">弹幕内容</view>
						</view>
						<u-input ref="inf" v-model="danmuValue" class="uni-input" placeholder="在此处输入弹幕内容" />
					</view>
				</view>
				<view>
					<u-divider>消息列表：</u-divider>
					<scroll-view :scroll-top="top" scroll-y="true" style="height: 200rpx;" class="scroll-Y">
						<text :key="k" v-for="(v,k) in messageList">{{v.name}}: {{v.msg}}\n</text>
					</scroll-view>


				</view>
				<view class="uni-btn-v" style="margin-top: 50px;">
					<button @click="sendDanmu" class="page-body-button" type="primary">发送弹幕</button>
				</view>
				<view class="uni-btn-v" style="margin-top: 50rpx;">
					<button @click="syncVideo" class="page-body-button">同步</button>
				</view>
				<!-- #endif -->
			</view>
		</view>



	</view>
</template>

<script>
	const time_distance = 30 * 60;
	import API from "../../common/resource.js"
	export default {

		data() {
			return {
				src: '',
				video: {
					url: 'https://img.cdn.aliyun.dcloud.net.cn/guide/uniapp/%E7%AC%AC1%E8%AE%B2%EF%BC%88uni-app%E4%BA%A7%E5%93%81%E4%BB%8B%E7%BB%8D%EF%BC%89-%20DCloud%E5%AE%98%E6%96%B9%E8%A7%86%E9%A2%91%E6%95%99%E7%A8%8B@20200317.mp4',
					name: 'test'
				},
				danmuList: [{
						text: '卢玉婷是猪',
						color: '#ff0000',
						time: 1
					},
					{
						text: '爱猪猪',
						color: '#ff00ff',
						time: 3
					}
				],
				messageList: [],
				danmuValue: '',
				toUser: {},
				ready: false,
				master: false,
				videoContext: null,
				count: 0,
				lastTime: 0,
				name: '',
				top: 189

			}
		},

		methods: {
			onKeyInput(event) {
				this.danmuValue = event.detail.value
			},
			topPush() {
				this.top = this.top + 200;
			},
			syncVideo() {

				let t = Math.ceil(this.lastTime);
				this.$im.sendMsgForText(t, this.toUser.name, 12, 1);


			},
			videoEvent(type, event) {

				//邀请者
				if (this.master) {

					if (type == 'play') {

						if (!this.ready && this.name != 'pps') {
							this.$ppsUtil.errorToast("邀请人还未到！")
							this.videoContext.pause();
							return;
						}
						this.$im.sendMsgForText('play', this.toUser.name, 11, 1);

					} else if (type == 'timeUpdate') {

						//60秒更新一次进度 或者用户拖动进度条
						let time = event.detail.currentTime
						this.count++;
						let ds = time - this.lastTime;
						if (ds >= 5 || ds <= -5 || this.count % 240 == 0) {
							let t = Math.ceil(time);
							this.$im.sendMsgForText(t, this.toUser.name, 12, 1);
						}
						this.lastTime = time;


					} else if (type == 'pause') {

						this.$im.sendMsgForText('pause', this.toUser.name, 11, 1);
						this.messageList.push({
							name: "系统通知",
							msg: this.name + "已暂停播放"
						})
						this.topPush();
					}

					//被已邀请者
				} else {

					if (type == 'timeUpdate') {

						//60秒更新一次进度 或者用户拖动进度条
						let time = event.detail.currentTime
						this.lastTime = time;


					}

				}


			},
			sendDanmu: function() {
				let vm = this;
				setTimeout(() => {

					let d = {
						text: this.danmuValue,
						color: this.getRandomColor()
					};
					vm.videoContext.sendDanmu(d);
					let tt = JSON.stringify(d);
					
					this.$im.sendMsgForText(
						tt,
						this.toUser.name,
						'8',
						this.$im.msgAction.sendToSingle
					);
					this.messageList.push({
						name: vm.toUser.name,
						msg: this.danmuValue
					})
					this.topPush();
					this.danmuValue = '';
				}, 150)



			},
			videoErrorCallback: function(e) {
				uni.showModal({
					content: e.target.errMsg,
					showCancel: false
				})
			},
			getRandomColor: function() {
				const rgb = []
				for (let i = 0; i < 3; ++i) {
					let color = Math.floor(Math.random() * 256).toString(16)
					color = color.length == 1 ? '0' + color : color
					rgb.push(color)
				}
				return '#' + rgb.join('')
			}
		},
		onBackPress() {

			this.$im.sendMsgForText('2', this.toUser.name, 10, 1);

		},
		onLoad(option) {
			const vm = this;
			this.count = 0;
			this.toUser = JSON.parse((option.item));
			this.video = JSON.parse(decodeURIComponent(option.video));
			this.name = this.vuex_user.userInfo.name;
			this.master = option.master == 'true' ? true : false;
			uni.$on('video-controller', function(data) {

				if (data == 'play') {
					vm.videoContext.play();
					vm.messageList.push({
						name: "系统提示",
						msg: vm.toUser.name + "已开始播放"
					})
				} else if (data == 'pause') {

					vm.videoContext.pause();
					vm.messageList.push({
						name: "系统提示",
						msg: vm.toUser.name + "已暂停播放"
					})
				}
				vm.topPush();

			})
			uni.$on('danmu', function(data) {

				vm.messageList.push({
					name: vm.toUser.name,
					msg: data.text
				})
				vm.videoContext.sendDanmu(data);
				vm.topPush();
			})

			uni.$on('timeUpdate', function(data) {

				vm.videoContext.seek(data)
				vm.messageList.push({
					name: "系统提示",
					msg: vm.toUser.name + "已同步至" + data + "秒"
				})
				vm.topPush();
			})
			uni.$on('userOut', function(data) {
				vm.messageList.push({
					name: "系统提示",
					msg: data + "已暂时下线"
				})
				vm.topPush();
			})
			uni.$on('invite-response', function(data) {
				if (data == '0') {
					vm.$ppsUtil.errorToast(this.toUser.name + ":该用户拒绝了你的邀请!")
					vm.messageList.push({
						name: "系统提示",
						msg: vm.toUser.name + "拒绝了你的邀请!"
					})
				} else if (data == '1') {
					vm.ready = true;
					vm.$ppsUtil.successToast(vm.toUser.name + ':已加入!')
					vm.messageList.push({
						name: "系统提示",
						msg: vm.toUser.name + "已加入该房间"
					})
				} else if (data == '2') {
					vm.$ppsUtil.successToast(vm.toUser.name + ':已退出房间!')
					vm.messageList.push({
						name: "系统提示",
						msg: vm.toUser.name + "已退出该房间"
					})
				}
				vm.topPush();
			})
		},
		onReady: function(res) {

			this.videoContext = uni.createVideoContext('myVideo')
		}

	}
</script>

<style lang="scss" scoped>
	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		padding: 40rpx;
	}
</style>

export default {
  getLoginInfo:"jwt/system/getLoginInfo",
  login:"login",
  initUpload:"jwt/file/chunck/init",
  uploadChunck:"jwt/file/chunck/upload",
  uploadSimple:"jwt/file/simple/upload",
  searchProcess:"jwt/file/chunck/process",
  completeUpload:"jwt/file/chunck/complete",
  getVideoList:"jwt/video/list",
  getOnile:'jwt/im/get/online',
  searchVideo:'jwt/v6/search',
  updateExtInfo:'/jwt/user/update',
  getResource:'jwt/v6/source',//获得播放源
  clickVideo:'jwt/v6/getPlayList',//获得播放链接
  getVideoLink:'jwt/v6/getHttpLink',//获取电影真实连接,
  uploadMovie:"/jwt/video/add",
  anlyHtml:"jwt/v6/analy"
}
